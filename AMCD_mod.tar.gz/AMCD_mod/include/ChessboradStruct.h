#pragma once

#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

#include <vector>
#include "HeaderCB.h"



class ChessboradStruct
{
public:
	ChessboradStruct();
	~ChessboradStruct();

	cv::Mat initChessboard(Corners& corners, int idx);
	void chessboardsFromCorners(Corners& corners, std::vector<cv::Mat>& chessboards);
	int directionalNeighbor(int idx, cv::Vec2f v, cv::Mat chessboard, Corners& corners, int& neighbor_idx, float& min_dist);
	float chessboardEnergy(cv::Mat chessboard, Corners& corners, float lamda = 0.5);
	void predictCorners(std::vector<cv::Vec2f>& p1, std::vector<cv::Vec2f>& p2, std::vector<cv::Vec2f>& p3, std::vector<cv::Vec2f>& pred);
	cv::Mat growChessboard(cv::Mat chessboard, Corners& corners, int border_type);
	void assignClosestCorners(std::vector<cv::Vec2f>&cand, std::vector<cv::Vec2f>&pred, std::vector<int> &idx);
	void drawchessboard(cv::Mat img, Corners& corners, std::vector<cv::Mat>& chessboards, char * title = "chessboard", int t = 0, cv::Rect rect = cv::Rect(0,0,0,0));
	void savechesspts(cv::Mat img, Corners& corners, std::vector<cv::Mat>& chessboards, const char * imagefilename = "img.bmp", const char * chessfilename = "pts.txt");
	void GetRefinePts(cv::Mat& img, Corners& corners, std::vector<cv::Mat>& chessboards, ImageChessesStruct &ics, bool& flagbeginfromzero);
	void GetRefinePts(cv::Rect& rect, std::vector<cv::Point2f>& circles, Corners& corners, std::vector<cv::Mat>& chessboards, ImageChessesStruct &ics, bool& flagbeginfromzero);
	
	cv::Mat chessboard;

};

