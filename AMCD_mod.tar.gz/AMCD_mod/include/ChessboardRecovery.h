#pragma once
#include "HeaderCB.h"


class ChessboardRecovery
{
public:
	ChessboardRecovery();
	~ChessboardRecovery();

	void ChessboardRecoveryRun(cv::Mat& src, Corners& corners, std::vector<cv::Mat>& chessboards, ImageChessesStruct& ChessesStruct, bool isshow);
};

