/*  Copyright 2017 only(997737609@qq.com). All Rights Reserved.           */
/*                                                                        */
/*  This file is part of ACRC.                                            */
/*                                                                        */
/*  part of source code come from https://github.com/qibao77/cornerDetect */
/*  Automatic Camera and Range Sensor Calibration using a single Shot     */
/*  this project realize the papar: Automatic Camera and Range Sensor     */
/*  Calibration using a single Shot                                       */
/*  the chess recovery class source code can contact 997737609@qq.com     */

#pragma once

#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

#include <iostream>
#include <vector>

#include "HeaderCB.h"

#if 1
#define  mtype CV_32F
#define  dtype  float
#else
#define  mtype CV_64F
#define dtype  double
#endif


class CornerDetAC
{
public:
	CornerDetAC();
	~CornerDetAC();
	CornerDetAC(cv::Mat img);
	void detectCorners(cv::Mat &Src, std::vector<cv::Point> &resultCornors, Corners& mcorners, dtype scoreThreshold, bool isrefine = true);
	void chessboardsFromCorners(std::vector<std::vector<cv::Point2f>>chessboards);
	void savecorners(Corners& mcorners, char * filename);
	void readcorners(Corners& mcorners, char * filename);
private:
	//正态分布
	dtype normpdf(dtype dist, dtype mu, dtype sigma);
	//获取最小值
	void getMin(cv::Mat src1, cv::Mat src2, cv::Mat &dst);
	//获取最大值
	void getMax(cv::Mat src1, cv::Mat src2, cv::Mat &dst);
	//获取梯度角度和权重
	void getImageAngleAndWeight(cv::Mat img, cv::Mat &imgDu, cv::Mat &imgDv, cv::Mat &imgAngle, cv::Mat &imgWeight);
	//estimate edge orientations
	void edgeOrientations(cv::Mat imgAngle, cv::Mat imgWeight, int index);
	//find modes of smoothed histogram
	void findModesMeanShift(std::vector<dtype> hist, std::vector<dtype> &hist_smoothed, std::vector<std::pair<dtype, int>> &modes, dtype sigma);
	//score corners
	void scoreCorners(cv::Mat img, cv::Mat imgAngle, cv::Mat imgWeight, std::vector<cv::Point2f> &cornors, std::vector<int> radius, std::vector<float> &score);
	//compute corner statistics
	void cornerCorrelationScore(cv::Mat img, cv::Mat imgWeight, std::vector<cv::Point2f> cornersEdge, float &score);
	//亚像素精度找角点
	void refineCorners(std::vector<cv::Point2f> &cornors, cv::Mat imgDu, cv::Mat imgDv, cv::Mat imgAngle, cv::Mat imgWeight, float radius);
	//生成核
	void createkernel(float angle1, float angle2, int kernelSize, cv::Mat &kernelA, cv::Mat &kernelB, cv::Mat &kernelC, cv::Mat &kernelD);
	//非极大值抑制
	void nonMaximumSuppression(cv::Mat& inputCorners, std::vector<cv::Point2f>& outputCorners, int patchSize, dtype threshold, int margin);
	float norm2d(cv::Point2f o);


	std::vector<cv::Point2f> templateProps;
	std::vector<int> radius;
	std::vector<cv::Point2f> cornerPoints;
	std::vector<std::vector<dtype>> cornersEdge1;
	std::vector<std::vector<dtype> > cornersEdge2;
	std::vector<cv::Point2f* > cornerPointsRefined;
	//Corners mcorners;
};
