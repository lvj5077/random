
/*  Copyright 2017 only(997737609@qq.com). All Rights Reserved.           */
/*                                                                        */
/*  This file is part of ACRC(自动多棋盘格提取).                          */
/*                                                                        */
/*  part of source code come from https://github.com/qibao77/cornerDetect */
/*  Automatic Camera and Range Sensor Calibration using a single Shot     */
/*  this project realize the papar: Automatic Camera and Range Sensor     */
/*  Calibration using a single Shot                                       */
/*  the chess recovery class source code can contact 997737609@qq.com     */


#include "ChessboardRecovery.h"
#include "opencv2/opencv.hpp"
#include "ChessboradStruct.h"



ChessboardRecovery::ChessboardRecovery()
{
}


ChessboardRecovery::~ChessboardRecovery()
{
}

void ChessboardRecovery::ChessboardRecoveryRun(cv::Mat& src, Corners& corners, std::vector<cv::Mat>& chessboards, ImageChessesStruct& ChessesStruct, bool isshow)
{
	ChessboradStruct chessboardstruct;
	cv::Mat disp;
	chessboardstruct.chessboardsFromCorners(corners, chessboards);
	// if (isshow == true)
	// {
	// 	chessboardstruct.drawchessboard(src, corners, chessboards, "cb", 0);
	// }
	// bool flagbeginfromzero;
	// chessboardstruct.GetRefinePts(src, corners, chessboards, ChessesStruct, flagbeginfromzero);
	// void savechesspts(cv::Mat img, Corners& corners, std::vector<cv::Mat>& chessboards, const char * imagefilename = "img.bmp", const char * chessfilename = "pts.txt");
	chessboardstruct.savechesspts(src,corners,chessboards,"img.png","pts.txt");
}
