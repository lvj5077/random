#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

#include <algorithm>
#include "CornerDetAC.h"
#include "ChessboardRecovery.h"

#include "HeaderCB.h"

#include <iostream>
#include <time.h>

using namespace cv;
using namespace std;
using std::vector;
vector<Point2i> points;

int main(int argc, char* argv[])
{

	Mat src1; 
	cv::Mat src;

	printf("read file...\n");

	string sr = "/home/jin/Lingqiu_Jin/AMCD_mod/data/setting_06_calib_04_img_left";

	string simage, stxt, ssave;
	simage = sr + ".png";
	stxt = sr + ".txt";
	ssave = sr + ".png";

	src1 = imread(simage.c_str(), -1);
	if (src1.channels() == 1)
	{
		src = src1.clone();
	}
	else
	{
		if (src1.channels() == 3)
		{
			cv::cvtColor(src1, src, CV_BGR2GRAY);
		}
		else
		{
			if (src1.channels() == 4)
			{
				cv::cvtColor(src1, src, CV_BGRA2GRAY);
			}
		}
	}

	if (src.empty())//不能读取图像
	{
		printf("Cannot read image file: %s\n", simage.c_str());
		return -1;
	}
	else
	{
		printf("read image file ok\n");
	}

	vector<Point> corners_p;//存储找到的角点
	
	double t = (double)getTickCount();
	
	CornerDetAC corner_detector(src);

	Corners corners_s;
	corner_detector.detectCorners(src, corners_p, corners_s, 0.01);
	printf("detectCorners ok\n");

	//corner_detector.savecorners(corners_s, "corner.txt");
	//corner_detector.readcorners(corners_s, "corner.txt");

	t = ((double)getTickCount() - t) / getTickFrequency();
	std::cout << "time cost :" << t << std::endl;
	ImageChessesStruct ics;
	std::vector<cv::Mat> chessboards;
	ChessboardRecovery cbr;
	cbr.ChessboardRecoveryRun(src1, corners_s, chessboards, ics, true);


	return 0;
}

